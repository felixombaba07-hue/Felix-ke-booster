// Deploy with: supabase functions deploy create-payment
// Keep PAYSTACK_SECRET_KEY server-side as a Supabase secret.
Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response(JSON.stringify({error:'Method not allowed'}),{status:405,headers:{'content-type':'application/json'}});
  const secret=Deno.env.get('PAYSTACK_SECRET_KEY');
  if(!secret) return new Response(JSON.stringify({error:'Payment function is not configured'}),{status:500,headers:{'content-type':'application/json'}});
  // TODO: authenticate the Supabase user, load the order from Postgres,
  // calculate the amount server-side, initialize Paystack, and return the authorization URL.
  return new Response(JSON.stringify({error:'Configure Paystack initialization in this function before accepting live payments.'}),{status:501,headers:{'content-type':'application/json'}});
});
